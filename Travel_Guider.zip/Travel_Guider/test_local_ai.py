"""
Test script for Local AI Recommender
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend.rag_system import RAGSystem
from data.data_loader import load_travel_guides

def test_local_ai():
    """Test the local AI recommender"""
    print("🧪 Testing Local AI Travel Recommender...")
    
    try:
        # Load documents
        documents = load_travel_guides()
        if not documents:
            print("❌ No documents available for testing")
            return False
        
        # Initialize RAG system
        rag_system = RAGSystem()
        rag_system.initialize(documents=documents)
        print("✅ RAG system initialized successfully")
        
        # Test query with local AI (will automatically fallback due to invalid API key)
        test_query = "Plan a 3-day trip to Goa for family with medium budget"
        print(f"🔍 Testing query: {test_query}")
        
        result = rag_system.query(
            user_query=test_query,
            budget="medium",
            travel_type="family",
            days=3
        )
        
        if result and not result.get("error"):
            print("✅ Query processed successfully")
            print(f"📊 Retrieved {result.get('retrieved_documents', 0)} documents")
            print(f"🤖 AI Source: {result.get('response_source', 'unknown')}")
            print(f"📝 Response preview:")
            print("=" * 50)
            print(result['response'][:500] + "..." if len(result['response']) > 500 else result['response'])
            print("=" * 50)
            return True
        else:
            print(f"❌ Query failed: {result.get('response', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_local_ai()
    if success:
        print("\n🎉 Local AI system is working perfectly!")
        print("The application will provide intelligent recommendations even without OpenAI API key.")
    else:
        print("\n❌ Local AI test failed.")