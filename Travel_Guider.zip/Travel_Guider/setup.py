"""
Setup script for AI Travel Guide Assistant
"""
import os
import sys
from dotenv import load_dotenv

def check_requirements():
    """Check if all required packages are installed"""
    try:
        import streamlit
        import openai
        import faiss
        import sentence_transformers
        print("✅ All required packages are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing package: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def check_environment():
    """Check environment variables"""
    load_dotenv()
    
    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key:
        print("❌ OPENAI_API_KEY not found in environment")
        print("Please:")
        print("1. Copy .env.example to .env")
        print("2. Add your OpenAI API key to .env")
        return False
    
    print("✅ Environment variables configured")
    return True

def setup_directories():
    """Create necessary directories"""
    directories = ["data", "data/travel_guides"]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"✅ Created directory: {directory}")
        else:
            print(f"✅ Directory exists: {directory}")

def main():
    """Main setup function"""
    print("🚀 Setting up AI Travel Guide Assistant...")
    print("=" * 50)
    
    # Check requirements
    if not check_requirements():
        sys.exit(1)
    
    # Setup directories
    setup_directories()
    
    # Check environment
    if not check_environment():
        print("\n⚠️  Setup incomplete. Please configure environment variables.")
        sys.exit(1)
    
    print("\n🎉 Setup complete!")
    print("\nTo run the application:")
    print("streamlit run app.py")

if __name__ == "__main__":
    main()