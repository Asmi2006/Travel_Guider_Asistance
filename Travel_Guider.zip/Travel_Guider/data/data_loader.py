"""
Data loader for travel guides and documents
"""
import os
from typing import List

def load_travel_guides(data_dir: str = "data/travel_guides") -> List[str]:
    """
    Load all travel guide documents from the data directory
    
    Args:
        data_dir: Directory containing travel guide text files
        
    Returns:
        List of document strings
    """
    documents = []
    
    if not os.path.exists(data_dir):
        print(f"Data directory {data_dir} not found")
        return documents
    
    for filename in os.listdir(data_dir):
        if filename.endswith('.txt'):
            filepath = os.path.join(data_dir, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content:
                        documents.append(content)
                        print(f"Loaded: {filename}")
            except Exception as e:
                print(f"Error loading {filename}: {e}")
    
    print(f"Total documents loaded: {len(documents)}")
    return documents

def get_sample_queries() -> List[dict]:
    """
    Get sample queries for testing the system
    
    Returns:
        List of sample query dictionaries
    """
    return [
        {
            "query": "Plan a 3-day trip to Goa for family",
            "budget": "medium",
            "travel_type": "family",
            "days": 3
        },
        {
            "query": "Best honeymoon destinations in India",
            "budget": "high",
            "travel_type": "honeymoon",
            "days": 7
        },
        {
            "query": "Adventure activities in Himachal Pradesh",
            "budget": "medium",
            "travel_type": "adventure",
            "days": 5
        },
        {
            "query": "Budget travel to Rajasthan",
            "budget": "low",
            "travel_type": "solo",
            "days": 10
        },
        {
            "query": "Kerala backwaters experience",
            "budget": "medium",
            "travel_type": "family",
            "days": 4
        }
    ]