"""
Test script for AI Travel Guide Assistant
"""
import os
import sys
from dotenv import load_dotenv

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend.rag_system import RAGSystem
from data.data_loader import load_travel_guides, get_sample_queries

def test_data_loading():
    """Test data loading functionality"""
    print("🧪 Testing data loading...")
    documents = load_travel_guides()
    
    if documents:
        print(f"✅ Successfully loaded {len(documents)} documents")
        print(f"📄 Sample document preview: {documents[0][:100]}...")
        return True
    else:
        print("❌ Failed to load documents")
        return False

def test_rag_system():
    """Test RAG system initialization and query"""
    print("\n🧪 Testing RAG system...")
    
    try:
        # Load documents
        documents = load_travel_guides()
        if not documents:
            print("❌ No documents available for testing")
            return False
        
        # Initialize RAG system
        rag_system = RAGSystem()
        rag_system.initialize(documents=documents)
        print("✅ RAG system initialized successfully")
        
        # Test query
        test_query = "Plan a 3-day trip to Goa for family"
        print(f"🔍 Testing query: {test_query}")
        
        result = rag_system.query(
            user_query=test_query,
            budget="medium",
            travel_type="family",
            days=3
        )
        
        if result and not result.get("error"):
            print("✅ Query processed successfully")
            print(f"📊 Retrieved {result.get('retrieved_documents', 0)} documents")
            print(f"📝 Response preview: {result['response'][:200]}...")
            return True
        else:
            print(f"❌ Query failed: {result.get('response', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"❌ RAG system test failed: {str(e)}")
        return False

def test_environment():
    """Test environment configuration"""
    print("\n🧪 Testing environment...")
    load_dotenv()
    
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        print("✅ OpenAI API key found")
        return True
    else:
        print("❌ OpenAI API key not found")
        print("Please set OPENAI_API_KEY in .env file")
        return False

def main():
    """Run all tests"""
    print("🚀 Running AI Travel Guide Assistant Tests")
    print("=" * 50)
    
    tests = [
        ("Environment", test_environment),
        ("Data Loading", test_data_loading),
        ("RAG System", test_rag_system)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test crashed: {str(e)}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("\n🎉 All tests passed! System is ready to use.")
        print("Run: streamlit run app.py")
    else:
        print("\n⚠️  Some tests failed. Please check the issues above.")

if __name__ == "__main__":
    main()