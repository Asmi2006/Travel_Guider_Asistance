# AI-Powered Travel Guide Assistant

A full-stack web application that uses RAG (Retrieval Augmented Generation) to provide personalized travel recommendations.

## 🌟 Features

- **Natural Language Queries**: Ask travel questions in plain English
- **Personalized Recommendations**: Based on budget, travel type, and duration
- **Fast AI Responses**: Optimized RAG system with vector search
- **Rich Travel Database**: Covers 7+ popular Indian destinations
- **Interactive UI**: Clean, responsive Streamlit interface
- **Real-time Processing**: Instant AI-generated travel guides

## 🏗️ Architecture

- **Frontend**: Streamlit for interactive UI
- **Backend**: Python with modular RAG system
- **AI System**: OpenAI GPT + Sentence Transformers + FAISS
- **Vector Database**: FAISS for fast similarity search
- **Data**: Curated travel guides with detailed information

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- OpenAI API key

### Installation

1. **Clone and setup**:
```bash
git clone <repository-url>
cd travel-guide-assistant
pip install -r requirements.txt
```

2. **Configure environment**:
```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

3. **Run setup**:
```bash
python setup.py
```

4. **Start the application**:
```bash
streamlit run app.py
```

5. **Open browser**: Navigate to `http://localhost:8501`

## 📁 Project Structure

```
travel-guide-assistant/
├── app.py                    # Main Streamlit application
├── setup.py                  # Setup and validation script
├── requirements.txt          # Python dependencies
├── .env.example             # Environment variables template
├── README.md               # Documentation
├── backend/                # Core AI system
│   ├── __init__.py
│   ├── rag_system.py       # Main RAG orchestrator
│   ├── vector_store.py     # FAISS vector operations
│   └── llm_client.py       # OpenAI integration
└── data/                   # Travel data and utilities
    ├── __init__.py
    ├── data_loader.py      # Document loading utilities
    └── travel_guides/      # Travel destination guides
        ├── goa.txt
        ├── kerala.txt
        ├── rajasthan.txt
        ├── himachal.txt
        ├── agra.txt
        ├── mumbai.txt
        └── delhi.txt
```

## 🎯 How It Works

### RAG System Flow
1. **Document Ingestion**: Travel guides are loaded and converted to embeddings
2. **Vector Storage**: Embeddings stored in FAISS index for fast retrieval
3. **Query Processing**: User query enhanced with preferences (budget, type, days)
4. **Retrieval**: Similar documents found using vector similarity search
5. **Generation**: OpenAI GPT generates personalized response with context
6. **Response**: Formatted travel recommendations displayed to user

### Key Components

**RAG System** (`backend/rag_system.py`):
- Orchestrates the entire RAG pipeline
- Handles query enhancement and context preparation
- Manages user preferences integration

**Vector Store** (`backend/vector_store.py`):
- FAISS-based vector database operations
- Sentence Transformers for embeddings
- Efficient similarity search and indexing

**LLM Client** (`backend/llm_client.py`):
- OpenAI API integration
- Prompt engineering for travel recommendations
- Response optimization and error handling

## 🗺️ Available Destinations

The system includes detailed guides for:
- **Goa**: Beaches, nightlife, Portuguese heritage
- **Kerala**: Backwaters, hill stations, Ayurveda
- **Rajasthan**: Palaces, deserts, cultural heritage
- **Himachal Pradesh**: Mountains, adventure sports, hill stations
- **Agra**: Taj Mahal, Mughal architecture
- **Mumbai**: Bollywood, street food, urban experiences
- **Delhi**: Historical monuments, diverse culture

## 💡 Usage Examples

### Sample Queries
- "Plan a 3-day trip to Goa for family with medium budget"
- "Best honeymoon destinations in India for 7 days"
- "Adventure activities in Himachal Pradesh for 5 days"
- "Budget travel to Rajasthan for solo traveler"
- "Kerala backwaters experience for family"

### Preferences
- **Budget**: Low (₹1500-3000/day), Medium (₹3000-6000/day), High (₹6000+/day)
- **Travel Type**: Solo, Family, Adventure, Honeymoon
- **Duration**: 1-30 days

## ⚙️ Configuration

### Environment Variables (.env)
```bash
# Required
OPENAI_API_KEY=your_openai_api_key_here

# Optional (with defaults)
MODEL_NAME=gpt-3.5-turbo
EMBEDDING_MODEL=all-MiniLM-L6-v2
MAX_TOKENS=500
TEMPERATURE=0.7
```

### Customization Options
- **Add New Destinations**: Create new `.txt` files in `data/travel_guides/`
- **Modify UI**: Edit `app.py` Streamlit components
- **Adjust AI Behavior**: Modify prompts in `llm_client.py`
- **Change Models**: Update embedding model in `vector_store.py`

## 🔧 Technical Details

### Dependencies
- **streamlit**: Web application framework
- **openai**: GPT model integration
- **faiss-cpu**: Vector similarity search
- **sentence-transformers**: Text embeddings
- **python-dotenv**: Environment management

### Performance Optimizations
- **Caching**: Streamlit caching for RAG system initialization
- **Vector Search**: FAISS for sub-second retrieval
- **Context Limiting**: Optimized prompt size for faster responses
- **Embedding Reuse**: Persistent vector index storage

## 🚨 Troubleshooting

### Common Issues

**"OPENAI_API_KEY not found"**
- Ensure `.env` file exists with valid API key
- Check API key format and permissions

**"No travel documents found"**
- Verify `data/travel_guides/` contains `.txt` files
- Run `python setup.py` to validate setup

**Slow responses**
- Check internet connection for OpenAI API
- Consider using smaller embedding model
- Reduce `MAX_TOKENS` in `.env`

**Import errors**
- Run `pip install -r requirements.txt`
- Ensure Python 3.8+ is being used

## 🔮 Future Enhancements

- **Multi-language Support**: Support for regional languages
- **Image Integration**: Visual travel recommendations
- **Real-time Data**: Live pricing and availability
- **User Profiles**: Personalized recommendation history
- **Advanced Filters**: Weather, festivals, crowd levels
- **Booking Integration**: Direct hotel/flight booking links

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add new travel guides or improve existing features
4. Submit a pull request

---

**Built with ❤️ using Python, Streamlit, OpenAI, and FAISS**