"""
AI-Powered Travel Guide Assistant - Main Streamlit Application
"""
import streamlit as st
import os
import sys
from typing import Dict, Any

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend.rag_system import RAGSystem
from data.data_loader import load_travel_guides, get_sample_queries

# Page configuration
st.set_page_config(
    page_title="AI Travel Guide Assistant",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        color: #2E86AB;
        margin-bottom: 2rem;
    }
    .query-box {
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 3px solid #2E86AB;
    }
    .response-box {
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #2E86AB;
        margin: 1rem 0;
    }
    .sidebar-content {
        padding: 1rem;
        border-radius: 10px;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def initialize_rag_system():
    """Initialize the RAG system with caching"""
    try:
        with st.spinner("Initializing AI Travel Assistant..."):
            # Load travel documents
            documents = load_travel_guides()
            
            if not documents:
                st.error("No travel documents found. Please check the data directory.")
                return None
            
            # Initialize RAG system
            rag_system = RAGSystem()
            rag_system.initialize(documents=documents)
            
            return rag_system
    except Exception as e:
        st.error(f"Error initializing system: {str(e)}")
        return None

def main():
    # Header
    st.markdown("<h1 class='main-header'>🌍 AI-Powered Travel Guide Assistant</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #666;'>Get personalized travel recommendations powered by AI</p>", unsafe_allow_html=True)
    
    # Initialize RAG system
    rag_system = initialize_rag_system()
    
    if not rag_system:
        st.stop()
    
    # Sidebar for preferences
    with st.sidebar:
        st.markdown("<div class='sidebar-content'>", unsafe_allow_html=True)
        st.header("🎯 Travel Preferences")
        
        # Budget selection
        budget = st.selectbox(
            "💰 Budget Range",
            ["low", "medium", "high"],
            index=1,
            help="Select your budget preference for recommendations"
        )
        
        # Travel type selection
        travel_type = st.selectbox(
            "👥 Travel Type",
            ["solo", "family", "adventure", "honeymoon"],
            index=1,
            help="Choose your travel style"
        )
        
        # Number of days
        days = st.slider(
            "📅 Number of Days",
            min_value=1,
            max_value=30,
            value=3,
            help="Duration of your trip"
        )
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Sample queries
        st.header("💡 Sample Queries")
        sample_queries = get_sample_queries()
        
        for i, sample in enumerate(sample_queries[:3]):
            if st.button(f"📝 {sample['query'][:30]}...", key=f"sample_{i}"):
                st.session_state.sample_query = sample['query']
                st.session_state.sample_budget = sample['budget']
                st.session_state.sample_travel_type = sample['travel_type']
                st.session_state.sample_days = sample['days']
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Query input
        st.subheader("🔍 Ask Your Travel Question")
        
        # Use sample query if selected
        default_query = ""
        if hasattr(st.session_state, 'sample_query'):
            default_query = st.session_state.sample_query
            # Update preferences from sample
            if hasattr(st.session_state, 'sample_budget'):
                budget = st.session_state.sample_budget
            if hasattr(st.session_state, 'sample_travel_type'):
                travel_type = st.session_state.sample_travel_type
            if hasattr(st.session_state, 'sample_days'):
                days = st.session_state.sample_days
        
        user_query = st.text_area(
            "Enter your travel question:",
            value=default_query,
            height=100,
            placeholder="e.g., Plan a 3-day trip to Goa for family with medium budget"
        )
        
        # Submit button
        if st.button("🚀 Get Travel Recommendations", type="primary"):
            if user_query.strip():
                with st.spinner("🤖 AI is crafting your personalized travel guide..."):
                    # Process query
                    result = rag_system.query(
                        user_query=user_query,
                        budget=budget,
                        travel_type=travel_type,
                        days=days
                    )
                    
                    # Display results
                    if result.get("error"):
                        st.error(result["response"])
                    else:
                        # Query summary
                        st.markdown("<div class='query-box'>", unsafe_allow_html=True)
                        st.write("**Your Query:**", user_query)
                        st.write(f"**Preferences:** {budget.title()} budget • {travel_type.title()} travel • {days} days")
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        # AI Response
                        st.markdown("<div class='response-box'>", unsafe_allow_html=True)
                        st.markdown("### 🎯 AI Travel Recommendations")
                        
                        # Show AI source
                        ai_source = result.get("response_source", "unknown")
                        if ai_source == "local_ai":
                            st.info("🤖 **Powered by Local AI** - Using intelligent rule-based recommendations")
                        elif ai_source == "openai":
                            st.success("🚀 **Powered by OpenAI GPT** - Advanced AI recommendations")
                        
                        st.markdown(result["response"])
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        # Metadata
                        with st.expander("📊 Query Details"):
                            st.write(f"**Documents Retrieved:** {result.get('retrieved_documents', 0)}")
                            st.write(f"**Enhanced Query:** {result.get('query', user_query)}")
            else:
                st.warning("Please enter a travel question to get recommendations.")
    
    with col2:
        # Information panel
        st.subheader("ℹ️ How It Works")
        st.markdown("""
        **Our AI Travel Assistant uses:**
        
        🔍 **Smart Search**: Finds relevant travel information from our database
        
        🤖 **Dual AI System**: 
        - OpenAI GPT for advanced recommendations (requires API key)
        - Local AI for intelligent rule-based suggestions (works offline)
        
        📚 **Rich Database**: Covers popular Indian destinations with detailed guides
        
        ⚡ **Fast Response**: Optimized for quick and accurate results
        """)
        
        # API Key status
        st.subheader("🔑 API Configuration")
        import os
        from dotenv import load_dotenv
        load_dotenv()
        
        api_key = os.getenv("OPENAI_API_KEY", "")
        if api_key and api_key != "your_openai_api_key_here":
            st.success("✅ OpenAI API configured - Premium AI responses enabled")
        else:
            st.warning("⚠️ Using Local AI - Add OpenAI API key to .env for premium responses")
            with st.expander("How to add OpenAI API key"):
                st.markdown("""
                1. Get API key from https://platform.openai.com/api-keys
                2. Edit `.env` file in project root
                3. Replace `your_openai_api_key_here` with your actual key
                4. Restart the application
                """)
        
        # Available destinations
        st.subheader("🗺️ Available Destinations")
        destinations = [
            "🏖️ Goa", "🌴 Kerala", "🏰 Rajasthan", 
            "🏔️ Himachal Pradesh", "🕌 Agra", 
            "🏙️ Mumbai", "🏛️ Delhi"
        ]
        
        for dest in destinations:
            st.write(f"• {dest}")
        
        # Tips
        st.subheader("💡 Tips for Better Results")
        st.markdown("""
        • Be specific about your interests
        • Mention any special requirements
        • Include preferred activities
        • Specify group size if relevant
        """)

if __name__ == "__main__":
    main()