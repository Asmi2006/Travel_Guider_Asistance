"""
Simple run script for AI Travel Guide Assistant
"""
import os
import sys
import subprocess
from dotenv import load_dotenv

def check_environment():
    """Check if environment is properly configured"""
    load_dotenv()
    
    if not os.getenv("OPENAI_API_KEY"):
        print("❌ OPENAI_API_KEY not found!")
        print("Please:")
        print("1. Copy .env.example to .env")
        print("2. Add your OpenAI API key to .env")
        return False
    
    return True

def main():
    """Main run function"""
    print("🚀 Starting AI Travel Guide Assistant...")
    
    # Check environment
    if not check_environment():
        sys.exit(1)
    
    # Check if streamlit is installed
    try:
        import streamlit
    except ImportError:
        print("❌ Streamlit not installed!")
        print("Run: pip install -r requirements.txt")
        sys.exit(1)
    
    # Run the application
    print("🌐 Starting Streamlit server...")
    print("📱 Open your browser to: http://localhost:8501")
    print("⏹️  Press Ctrl+C to stop the server")
    
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", "app.py"])
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")

if __name__ == "__main__":
    main()