# Installation Guide

## Prerequisites

- **Python 3.8 or higher**
- **OpenAI API Key** (get from https://platform.openai.com/api-keys)
- **Internet connection** for downloading models and API calls

## Step-by-Step Installation

### 1. Download the Project
```bash
# If you have the project files, navigate to the directory
cd travel-guide-assistant
```

### 2. Install Python Dependencies
```bash
# Install all required packages
pip install -r requirements.txt

# Alternative: Install with specific versions
pip install streamlit==1.29.0 openai==1.3.0 faiss-cpu==1.7.4 sentence-transformers==2.2.2 python-dotenv==1.0.0
```

### 3. Set Up Environment Variables
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env file and add your OpenAI API key
# On Windows: notepad .env
# On Mac/Linux: nano .env
```

**Edit .env file to include:**
```
OPENAI_API_KEY=your_actual_api_key_here
MODEL_NAME=gpt-3.5-turbo
EMBEDDING_MODEL=all-MiniLM-L6-v2
MAX_TOKENS=500
TEMPERATURE=0.7
```

### 4. Validate Installation
```bash
# Run the setup script to check everything
python setup.py

# Run tests to ensure system works
python test_system.py
```

### 5. Start the Application
```bash
# Option 1: Use the run script
python run.py

# Option 2: Direct streamlit command
streamlit run app.py
```

### 6. Access the Application
- Open your web browser
- Navigate to: `http://localhost:8501`
- Start asking travel questions!

## Troubleshooting

### Common Issues and Solutions

#### "ModuleNotFoundError: No module named 'streamlit'"
**Solution:** Install requirements
```bash
pip install -r requirements.txt
```

#### "OPENAI_API_KEY not found"
**Solution:** 
1. Ensure `.env` file exists in project root
2. Add your OpenAI API key to `.env`
3. Restart the application

#### "No travel documents found"
**Solution:** 
1. Check that `data/travel_guides/` folder exists
2. Ensure it contains `.txt` files
3. Run `python setup.py` to validate

#### Slow responses or timeouts
**Solutions:**
1. Check internet connection
2. Verify OpenAI API key is valid and has credits
3. Reduce `MAX_TOKENS` in `.env` file
4. Try using `gpt-3.5-turbo` instead of `gpt-4`

#### "Error generating response: Rate limit exceeded"
**Solution:** 
1. Wait a few minutes and try again
2. Check your OpenAI account usage limits
3. Consider upgrading your OpenAI plan

#### Import errors with FAISS
**Solution:**
```bash
# Try installing CPU version specifically
pip uninstall faiss-cpu faiss-gpu
pip install faiss-cpu==1.7.4

# On some systems, you might need:
conda install faiss-cpu -c conda-forge
```

## System Requirements

### Minimum Requirements
- **RAM:** 4GB (8GB recommended)
- **Storage:** 2GB free space
- **CPU:** Any modern processor
- **Internet:** Stable connection for API calls

### Recommended Setup
- **RAM:** 8GB or more
- **Storage:** 5GB free space
- **CPU:** Multi-core processor
- **Internet:** High-speed connection

## Development Setup

If you want to modify or extend the system:

### 1. Install Development Dependencies
```bash
pip install -r requirements.txt
pip install jupyter notebook pytest black flake8
```

### 2. Project Structure Understanding
```
travel-guide-assistant/
├── app.py                    # Main Streamlit UI
├── backend/                  # Core AI system
│   ├── rag_system.py        # RAG orchestrator
│   ├── vector_store.py      # FAISS operations
│   └── llm_client.py        # OpenAI integration
├── data/                    # Travel data
│   ├── data_loader.py       # Data utilities
│   └── travel_guides/       # Text documents
├── test_system.py           # System tests
├── setup.py                 # Setup validation
└── run.py                   # Easy startup script
```

### 3. Adding New Destinations
1. Create new `.txt` file in `data/travel_guides/`
2. Follow the format of existing guides
3. Restart the application to rebuild the index

### 4. Customizing the UI
- Edit `app.py` for Streamlit interface changes
- Modify CSS in the `st.markdown()` sections
- Add new input components as needed

### 5. Modifying AI Behavior
- Edit prompts in `backend/llm_client.py`
- Adjust retrieval parameters in `backend/vector_store.py`
- Modify query enhancement in `backend/rag_system.py`

## Performance Optimization

### For Better Speed
1. **Use faster embedding models:**
   ```
   EMBEDDING_MODEL=all-MiniLM-L6-v2  # Fast, good quality
   ```

2. **Reduce token limits:**
   ```
   MAX_TOKENS=300  # Faster responses
   ```

3. **Cache the vector index:**
   - Index is automatically saved after first build
   - Subsequent runs will be faster

### For Better Quality
1. **Use larger embedding models:**
   ```
   EMBEDDING_MODEL=all-mpnet-base-v2  # Slower, better quality
   ```

2. **Increase context:**
   ```
   MAX_TOKENS=800  # More detailed responses
   ```

3. **Use GPT-4:**
   ```
   MODEL_NAME=gpt-4  # Better quality, higher cost
   ```

## Security Notes

- **API Key Security:** Never commit `.env` file to version control
- **Local Only:** This setup runs locally, your data stays on your machine
- **API Calls:** Only queries are sent to OpenAI, travel data stays local

## Getting Help

1. **Check the logs:** Look at terminal output for error messages
2. **Run tests:** Use `python test_system.py` to diagnose issues
3. **Validate setup:** Use `python setup.py` to check configuration
4. **Check requirements:** Ensure all packages are installed correctly

## Next Steps

Once installed successfully:
1. Try the sample queries in the sidebar
2. Experiment with different preferences
3. Ask about your favorite destinations
4. Explore the system's capabilities

Happy travels! 🌍✈️