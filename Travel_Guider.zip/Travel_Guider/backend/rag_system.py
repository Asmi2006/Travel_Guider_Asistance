"""
RAG (Retrieval Augmented Generation) System
Combines vector search with LLM generation
"""
import os
from typing import List, Dict, Any
from .vector_store import VectorStore
from .llm_client import LLMClient
from .local_recommender import LocalTravelRecommender

class RAGSystem:
    def __init__(self):
        self.vector_store = VectorStore()
        self.llm_client = LLMClient()
        self.local_recommender = LocalTravelRecommender()
        self.is_initialized = False
        self.use_local_fallback = False
    
    def initialize(self, documents: List[str] = None, index_path: str = "data/travel_index"):
        """
        Initialize the RAG system with documents or load existing index
        
        Args:
            documents: List of documents to index (if creating new)
            index_path: Path to save/load index
        """
        try:
            # Try to load existing index
            if os.path.exists(f"{index_path}.faiss"):
                self.vector_store.load_index(index_path)
                print("Loaded existing index")
            elif documents:
                # Build new index from documents
                self.vector_store.build_index(documents)
                # Save the index
                os.makedirs(os.path.dirname(index_path), exist_ok=True)
                self.vector_store.save_index(index_path)
                print("Built and saved new index")
            else:
                raise ValueError("No existing index found and no documents provided")
            
            self.is_initialized = True
            
        except Exception as e:
            print(f"Error initializing RAG system: {e}")
            raise
    
    def query(self, 
              user_query: str, 
              budget: str = "medium", 
              travel_type: str = "family", 
              days: int = 3,
              top_k: int = 5) -> Dict[str, Any]:
        """
        Process user query and generate response
        
        Args:
            user_query: User's travel question
            budget: Budget preference (low/medium/high)
            travel_type: Type of travel (solo/family/adventure/honeymoon)
            days: Number of days
            top_k: Number of documents to retrieve
            
        Returns:
            Dictionary with response and metadata
        """
        if not self.is_initialized:
            raise ValueError("RAG system not initialized. Call initialize() first.")
        
        try:
            # Enhance query with user preferences
            enhanced_query = self._enhance_query(user_query, budget, travel_type, days)
            
            # Retrieve relevant documents
            retrieved_docs = self.vector_store.search(enhanced_query, k=top_k)
            
            # Prepare context from retrieved documents
            context = self._prepare_context(retrieved_docs, budget, travel_type, days)
            
            # Try to generate response using LLM first
            try:
                response = self.llm_client.generate_response(enhanced_query, context)
                
                # Check if response indicates API key error
                if "error" in response.lower() and ("api key" in response.lower() or "401" in response):
                    print("OpenAI API not available, using local recommender...")
                    response = self.local_recommender.generate_recommendation(
                        user_query, retrieved_docs, budget, travel_type, days
                    )
                    response_source = "local_ai"
                else:
                    response_source = "openai"
                    
            except Exception as llm_error:
                print(f"LLM error: {llm_error}, using local recommender...")
                response = self.local_recommender.generate_recommendation(
                    user_query, retrieved_docs, budget, travel_type, days
                )
                response_source = "local_ai"
            
            return {
                "response": response,
                "retrieved_documents": len(retrieved_docs),
                "query": enhanced_query,
                "response_source": response_source,
                "preferences": {
                    "budget": budget,
                    "travel_type": travel_type,
                    "days": days
                }
            }
            
        except Exception as e:
            return {
                "response": f"Sorry, I encountered an error: {str(e)}",
                "error": True
            }
    
    def _enhance_query(self, query: str, budget: str, travel_type: str, days: int) -> str:
        """Enhance user query with preferences for better retrieval"""
        enhancements = []
        
        if budget:
            enhancements.append(f"{budget} budget")
        if travel_type:
            enhancements.append(f"{travel_type} travel")
        if days:
            enhancements.append(f"{days} days")
        
        if enhancements:
            return f"{query} {' '.join(enhancements)}"
        return query
    
    def _prepare_context(self, retrieved_docs: List[tuple], budget: str, travel_type: str, days: int) -> str:
        """Prepare context from retrieved documents"""
        context_parts = []
        
        # Add user preferences to context
        context_parts.append(f"User Preferences: Budget: {budget}, Travel Type: {travel_type}, Duration: {days} days")
        context_parts.append("\nRelevant Travel Information:")
        
        # Add retrieved documents
        for i, (doc, score) in enumerate(retrieved_docs, 1):
            context_parts.append(f"\n{i}. {doc}")
        
        return "\n".join(context_parts)