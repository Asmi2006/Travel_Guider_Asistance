"""
Local Travel Recommender - Works without OpenAI API
Provides intelligent travel recommendations using rule-based logic and retrieved documents
"""
import re
from typing import List, Tuple, Dict, Any

class LocalTravelRecommender:
    def __init__(self):
        self.budget_mapping = {
            "low": {"min": 1500, "max": 3000, "desc": "budget-friendly"},
            "medium": {"min": 3000, "max": 6000, "desc": "comfortable"},
            "high": {"min": 6000, "max": 15000, "desc": "luxury"}
        }
        
        self.travel_type_keywords = {
            "family": ["family", "children", "kids", "safe", "comfortable", "educational"],
            "solo": ["solo", "backpacker", "independent", "flexible", "adventure"],
            "adventure": ["adventure", "trekking", "sports", "climbing", "rafting", "extreme"],
            "honeymoon": ["honeymoon", "romantic", "couple", "private", "luxury", "peaceful"]
        }
    
    def generate_recommendation(self, query: str, retrieved_docs: List[Tuple[str, float]], 
                              budget: str, travel_type: str, days: int) -> str:
        """
        Generate travel recommendation using local intelligence
        """
        try:
            # Extract destination from query and docs
            destination = self._extract_destination(query, retrieved_docs)
            
            # Get budget info
            budget_info = self.budget_mapping.get(budget, self.budget_mapping["medium"])
            
            # Build recommendation
            recommendation = self._build_recommendation(
                destination, retrieved_docs, budget, travel_type, days, budget_info
            )
            
            return recommendation
            
        except Exception as e:
            return f"I apologize, but I encountered an error while generating your recommendation: {str(e)}"
    
    def _extract_destination(self, query: str, retrieved_docs: List[Tuple[str, float]]) -> str:
        """Extract the main destination from query and retrieved documents"""
        destinations = ["Goa", "Kerala", "Rajasthan", "Himachal", "Agra", "Mumbai", "Delhi"]
        
        # Check query first
        query_lower = query.lower()
        for dest in destinations:
            if dest.lower() in query_lower:
                return dest
        
        # Check retrieved documents
        if retrieved_docs:
            first_doc = retrieved_docs[0][0]
            for dest in destinations:
                if dest in first_doc:
                    return dest
        
        return "India"  # Default
    
    def _build_recommendation(self, destination: str, retrieved_docs: List[Tuple[str, float]], 
                            budget: str, travel_type: str, days: int, budget_info: Dict) -> str:
        """Build comprehensive travel recommendation"""
        
        # Extract relevant information from retrieved documents
        attractions = self._extract_attractions(retrieved_docs)
        activities = self._extract_activities(retrieved_docs, travel_type)
        food_info = self._extract_food_info(retrieved_docs)
        best_time = self._extract_best_time(retrieved_docs)
        
        # Build recommendation sections
        recommendation_parts = []
        
        # Header
        recommendation_parts.append(f"# 🌟 {days}-Day {destination} Travel Plan")
        recommendation_parts.append(f"**Perfect for:** {travel_type.title()} travelers | **Budget:** {budget_info['desc'].title()} (₹{budget_info['min']}-{budget_info['max']}/day)")
        
        # Best time to visit
        if best_time:
            recommendation_parts.append(f"\n## 📅 Best Time to Visit\n{best_time}")
        
        # Itinerary
        itinerary = self._create_itinerary(destination, days, travel_type, attractions, activities)
        recommendation_parts.append(f"\n## 🗓️ Suggested Itinerary\n{itinerary}")
        
        # Top attractions
        if attractions:
            recommendation_parts.append(f"\n## 🏛️ Must-Visit Attractions\n{attractions}")
        
        # Activities
        if activities:
            recommendation_parts.append(f"\n## 🎯 Recommended Activities\n{activities}")
        
        # Food recommendations
        if food_info:
            recommendation_parts.append(f"\n## 🍽️ Local Cuisine\n{food_info}")
        
        # Budget breakdown
        budget_breakdown = self._create_budget_breakdown(budget_info, days)
        recommendation_parts.append(f"\n## 💰 Budget Breakdown\n{budget_breakdown}")
        
        # Travel tips
        tips = self._get_travel_tips(destination, travel_type)
        recommendation_parts.append(f"\n## 💡 Travel Tips\n{tips}")
        
        return "\n".join(recommendation_parts)
    
    def _extract_attractions(self, retrieved_docs: List[Tuple[str, float]]) -> str:
        """Extract top attractions from retrieved documents"""
        attractions = []
        for doc, score in retrieved_docs[:3]:
            # Look for attraction patterns
            lines = doc.split('\n')
            for line in lines:
                if any(keyword in line.lower() for keyword in ['attractions:', 'visit:', 'places:', 'fort', 'temple', 'beach', 'palace']):
                    if ':' in line and len(line) < 200:
                        attractions.append(f"• {line.strip()}")
        
        return '\n'.join(attractions[:8]) if attractions else "• Explore local landmarks and cultural sites\n• Visit popular tourist destinations\n• Experience local markets and shopping areas"
    
    def _extract_activities(self, retrieved_docs: List[Tuple[str, float]], travel_type: str) -> str:
        """Extract relevant activities based on travel type"""
        activities = []
        type_keywords = self.travel_type_keywords.get(travel_type, [])
        
        for doc, score in retrieved_docs[:3]:
            lines = doc.split('\n')
            for line in lines:
                line_lower = line.lower()
                if any(keyword in line_lower for keyword in ['activities:', 'things to do', 'experience']):
                    if ':' in line and len(line) < 200:
                        activities.append(f"• {line.strip()}")
                elif any(keyword in line_lower for keyword in type_keywords):
                    if len(line) < 150 and any(char in line for char in ['-', '•']):
                        activities.append(f"• {line.strip()}")
        
        if not activities:
            default_activities = {
                "family": ["• Family-friendly sightseeing tours", "• Cultural experiences and museums", "• Safe outdoor activities"],
                "solo": ["• Independent exploration", "• Local food tours", "• Photography walks"],
                "adventure": ["• Outdoor sports and activities", "• Trekking and hiking", "• Adventure sports"],
                "honeymoon": ["• Romantic dinners", "• Couple spa treatments", "• Private tours"]
            }
            activities = default_activities.get(travel_type, ["• Sightseeing", "• Local experiences", "• Cultural activities"])
        
        return '\n'.join(activities[:6])
    
    def _extract_food_info(self, retrieved_docs: List[Tuple[str, float]]) -> str:
        """Extract food and cuisine information"""
        food_items = []
        for doc, score in retrieved_docs[:2]:
            lines = doc.split('\n')
            for line in lines:
                if any(keyword in line.lower() for keyword in ['food:', 'cuisine', 'local food', 'dishes', 'eat']):
                    if ':' in line and len(line) < 150:
                        food_items.append(f"• {line.strip()}")
        
        return '\n'.join(food_items[:5]) if food_items else "• Try authentic local cuisine\n• Visit popular restaurants and food stalls\n• Experience regional specialties"
    
    def _extract_best_time(self, retrieved_docs: List[Tuple[str, float]]) -> str:
        """Extract best time to visit information"""
        for doc, score in retrieved_docs[:2]:
            lines = doc.split('\n')
            for line in lines:
                if 'best time' in line.lower():
                    return line.strip()
        return "Plan your visit during pleasant weather months for the best experience."
    
    def _create_itinerary(self, destination: str, days: int, travel_type: str, attractions: str, activities: str) -> str:
        """Create a day-by-day itinerary"""
        itinerary = []
        
        if days == 1:
            itinerary.append("**Day 1:** Arrival and main attractions tour")
        elif days == 2:
            itinerary.append("**Day 1:** Arrival, check-in, and local sightseeing")
            itinerary.append("**Day 2:** Main attractions and departure")
        elif days == 3:
            itinerary.append("**Day 1:** Arrival, check-in, and city orientation")
            itinerary.append("**Day 2:** Major attractions and cultural experiences")
            itinerary.append("**Day 3:** Local activities and departure")
        else:
            itinerary.append("**Day 1:** Arrival and settling in")
            itinerary.append("**Day 2-3:** Major attractions and sightseeing")
            if days > 4:
                itinerary.append(f"**Day 4-{days-1}:** Extended exploration and activities")
            itinerary.append(f"**Day {days}:** Final experiences and departure")
        
        return '\n'.join(itinerary)
    
    def _create_budget_breakdown(self, budget_info: Dict, days: int) -> str:
        """Create budget breakdown"""
        daily_budget = (budget_info['min'] + budget_info['max']) // 2
        total_budget = daily_budget * days
        
        breakdown = [
            f"**Daily Budget:** ₹{daily_budget} per day",
            f"**Total Estimated Cost:** ₹{total_budget} for {days} days",
            f"• Accommodation: 40-50% of budget",
            f"• Food: 25-30% of budget", 
            f"• Transportation: 15-20% of budget",
            f"• Activities & Shopping: 10-15% of budget"
        ]
        
        return '\n'.join(breakdown)
    
    def _get_travel_tips(self, destination: str, travel_type: str) -> str:
        """Get relevant travel tips"""
        general_tips = [
            "• Book accommodations in advance for better rates",
            "• Carry local currency for small vendors",
            "• Stay hydrated and carry water bottles",
            "• Respect local customs and traditions"
        ]
        
        type_specific_tips = {
            "family": ["• Choose family-friendly accommodations", "• Plan shorter travel distances", "• Keep emergency contacts handy"],
            "solo": ["• Share your itinerary with someone", "• Stay in well-reviewed accommodations", "• Trust your instincts"],
            "adventure": ["• Check weather conditions", "• Carry appropriate gear", "• Consider travel insurance"],
            "honeymoon": ["• Book romantic restaurants in advance", "• Consider couple packages", "• Plan some private time"]
        }
        
        tips = general_tips + type_specific_tips.get(travel_type, [])
        return '\n'.join(tips[:6])