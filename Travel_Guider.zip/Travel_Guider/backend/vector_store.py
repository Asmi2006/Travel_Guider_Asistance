"""
Vector Store implementation using FAISS for document embeddings
"""
import os
import pickle
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from typing import List, Tuple
from dotenv import load_dotenv

load_dotenv()

class VectorStore:
    def __init__(self, embedding_model: str = None):
        self.embedding_model_name = embedding_model or os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
        self.model = SentenceTransformer(self.embedding_model_name)
        self.index = None
        self.documents = []
        self.embeddings = None
        
    def create_embeddings(self, documents: List[str]) -> np.ndarray:
        """
        Create embeddings for a list of documents
        
        Args:
            documents: List of text documents
            
        Returns:
            Numpy array of embeddings
        """
        print(f"Creating embeddings for {len(documents)} documents...")
        embeddings = self.model.encode(documents, show_progress_bar=True)
        return embeddings
    
    def build_index(self, documents: List[str]):
        """
        Build FAISS index from documents
        
        Args:
            documents: List of text documents to index
        """
        self.documents = documents
        self.embeddings = self.create_embeddings(documents)
        
        # Create FAISS index
        dimension = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dimension)  # Inner product for cosine similarity
        
        # Normalize embeddings for cosine similarity
        faiss.normalize_L2(self.embeddings)
        self.index.add(self.embeddings)
        
        print(f"Built FAISS index with {len(documents)} documents")
    
    def search(self, query: str, k: int = 5) -> List[Tuple[str, float]]:
        """
        Search for similar documents
        
        Args:
            query: Search query
            k: Number of results to return
            
        Returns:
            List of (document, score) tuples
        """
        if self.index is None:
            raise ValueError("Index not built. Call build_index() first.")
        
        # Create query embedding
        query_embedding = self.model.encode([query])
        faiss.normalize_L2(query_embedding)
        
        # Search
        scores, indices = self.index.search(query_embedding, k)
        
        results = []
        for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx < len(self.documents):
                results.append((self.documents[idx], float(score)))
        
        return results
    
    def save_index(self, filepath: str):
        """Save the index and documents to disk"""
        if self.index is None:
            raise ValueError("No index to save")
        
        # Save FAISS index
        faiss.write_index(self.index, f"{filepath}.faiss")
        
        # Save documents and metadata
        with open(f"{filepath}.pkl", "wb") as f:
            pickle.dump({
                "documents": self.documents,
                "embedding_model": self.embedding_model_name
            }, f)
        
        print(f"Index saved to {filepath}")
    
    def load_index(self, filepath: str):
        """Load the index and documents from disk"""
        # Load FAISS index
        self.index = faiss.read_index(f"{filepath}.faiss")
        
        # Load documents and metadata
        with open(f"{filepath}.pkl", "rb") as f:
            data = pickle.load(f)
            self.documents = data["documents"]
            self.embedding_model_name = data["embedding_model"]
        
        print(f"Index loaded from {filepath}")
        return True