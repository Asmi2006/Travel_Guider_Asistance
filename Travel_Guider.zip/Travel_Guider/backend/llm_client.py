"""
LLM Client for handling OpenAI and HuggingFace model interactions
"""
import os
from typing import Optional
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class LLMClient:
    def __init__(self, model_name: str = None):
        self.model_name = model_name or os.getenv("MODEL_NAME", "gpt-3.5-turbo")
        self.max_tokens = int(os.getenv("MAX_TOKENS", "500"))
        self.temperature = float(os.getenv("TEMPERATURE", "0.7"))
        
        # Initialize OpenAI client
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        
        self.client = OpenAI(api_key=api_key)
    
    def generate_response(self, prompt: str, context: str = "") -> str:
        """
        Generate response using LLM with retrieved context
        
        Args:
            prompt: User query
            context: Retrieved relevant documents
            
        Returns:
            Generated response string
        """
        try:
            # Construct the full prompt with context
            full_prompt = self._construct_prompt(prompt, context)
            
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful travel guide assistant. Provide accurate, personalized travel recommendations based on the provided context."},
                    {"role": "user", "content": full_prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def _construct_prompt(self, query: str, context: str) -> str:
        """Construct the final prompt with context and user query"""
        return f"""
Based on the following travel information:

{context}

Please answer this travel query: {query}

Provide a helpful, detailed response with specific recommendations, including:
- Suggested itinerary if applicable
- Budget considerations
- Best times to visit
- Must-see attractions
- Local tips and recommendations

Keep the response concise but informative.
"""